package Utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Base 
{
   public static WebDriver driver;
   public static ExtentReports extent;
   public static ExtentTest test;
   public static String TimeStamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(Calendar.getInstance().getTime());
   public static Screen screen;
   public WebDriverWait wait = new WebDriverWait(driver, 10);
   public static PageObjects.SignUp su;
   public static PageObjects.Developers dp;
   public static PageObjects.SignUpFooter sf;
  
   public static String GetData (String nodeName) throws ParserConfigurationException, 
   SAXException, IOException
   {
	   File fXmlFile = new File("C:/Selenium Drivers/extentreports-java-2.41.2/Reports/FinalExam.html");
	   DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	   DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	   Document doc = dBuilder.parse(fXmlFile);
	   doc.getDocumentElement().normalize();
	   return doc.getElementsByTagName(nodeName).item(0).getTextContent();
	   
   }
   
   public static void InitBrowser(String BrowserType) throws ParserConfigurationException, SAXException, IOException
   {
	   switch (BrowserType.toLowerCase())
	   {
	   case "firefox":	
		   driver= InitFFDriver();
	       break; 
	   case "ie":
		   driver= InitIEDriver();
	       break; 
	   case "chrome":
		   driver= InitChromeDriver();
	       break; 
	   }
	   driver.manage().window().maximize();
	   driver.get(GetData("URL"));
	   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   screen = new Screen();
   }
   
   public static WebDriver InitFFDriver() throws ParserConfigurationException, SAXException, IOException
   {
	   System.setProperty("webdriver.gecko.driver", GetData("FFDriverPath"));
	   WebDriver driver = new FirefoxDriver();
	   return driver;
   }
   
   public static WebDriver InitIEDriver() throws ParserConfigurationException, SAXException, IOException
   {
	   System.setProperty("webdriver.ie.driver", GetData("IEDriverPath"));
	   WebDriver driver = new InternetExplorerDriver();
	   return driver;
   }
   
   public static WebDriver InitChromeDriver() throws ParserConfigurationException, SAXException, IOException
   {
	   System.setProperty("webdriver.chrome.driver", GetData("ChromeDriverPath"));
	   WebDriver driver = new ChromeDriver();
	   return driver;
   }
   
   public static void InitReports() throws ParserConfigurationException, SAXException, IOException
   {
	   extent = new ExtentReports(GetData("ReportFilePath") + GetData("ReportFileName") + TimeStamp + ".html", true);
   }
   
   public static void InitReportTest(String TestName, String TestDescription)
   {
	  test = extent.startTest(TestName, TestDescription); 
   }
   
   public static void FinalizeReportTest()
   {
	  extent.endTest(test); 
   }
   
   public static void FinalizeExtentReport()
   {
	  extent.flush(); 
	  extent.close();
   }
  
   public static String TakeSS() throws IOException, ParserConfigurationException, SAXException
   {
	   String SSPath = GetData("SSPath") + "screenshot_" + TimeStamp + ".png";
	   File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	   FileUtils.copyFile(scrFile, new File(SSPath));
	   return SSPath;
   }
   
	@Rule public TestName name = new TestName();
	
    @BeforeClass
    public static void StartTest() throws ParserConfigurationException, SAXException, IOException
    {
   	 InitBrowser(GetData("BrowserType"));
   	 InitReports();
   	 driver.get("https://www.facebook.com/");
        PageObjects.ManagePages.init();
    }

    @AfterClass
    public static void CloseTest()
    {
   	 driver.quit();
   	 FinalizeExtentReport();
    }
    
    @After
    public void AfterTest()
    {
   	 FinalizeReportTest();
    }
    
    @Before
    public void DoBeforeTest()
    {
   	 InitReportTest(name.getMethodName().split("_")[0], name.getMethodName().split("_")[1]);
    }
}
