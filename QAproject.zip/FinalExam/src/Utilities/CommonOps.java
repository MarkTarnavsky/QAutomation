package Utilities;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.xml.sax.SAXException;

import com.relevantcodes.extentreports.LogStatus;

import static org.junit.Assert.fail;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import static org.junit.Assert.*;

public class CommonOps extends Base 
{
	
       public static void SelectBirthDayMonth(WebElement elem, String Month) throws IOException, ParserConfigurationException, SAXException
       {
    	   try
    	   {
    		   Select MyMonth = new Select(elem);
    		   MyMonth.selectByValue(Month);	   
    		   System.out.println("Month selected");
    		   test.log(LogStatus.PASS, "Month selected");
    	   }
    	   catch(Exception e)
    	   {
    		   System.out.println("Month NOT selected");
    		   System.out.println(e);
    		   test.log(LogStatus.FAIL, "Month NOT selected !, see Screen Shot: "+ e.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Month NOT selected");
    	   }
       }
       
       public static void SelectBirthDayDay(WebElement elem, String Day) throws IOException, ParserConfigurationException, SAXException
       {
    	   try
    	   {
    		   Select MyDay = new Select(elem);
    		   MyDay.selectByValue(Day);	   
    		   System.out.println("Day selected");
    		   test.log(LogStatus.PASS, "Day selected");
    	   }
    	   catch(Exception e)
    	   {
    		   System.out.println("Day NOT selected");
    		   System.out.println(e);
    		   test.log(LogStatus.FAIL, "Day NOT selected !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Day NOT selected");
    	   }
       }
       
       public static void SelectBirthDayYear(WebElement elem, String Year) throws IOException, ParserConfigurationException, SAXException
       {
    	   try
    	   {
    		   Select MyYear = new Select(elem);
    		   MyYear.selectByValue(Year);	   
    		   System.out.println("Year selected");
    		   test.log(LogStatus.PASS, "Year selected");
    	   }
    	   catch(Exception e)
    	   {
    		   System.out.println("Year NOT selected");
    		   System.out.println(e);
    		   test.log(LogStatus.FAIL, "Year NOT selected !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Year NOT selected");
    	   }
       }
       
       public static void SelectGender(WebElement elem, String Gender) throws IOException, ParserConfigurationException, SAXException
       {
    	   try
    	   {
    		   Select MyGender = new Select(elem);
    		   MyGender.selectByValue(Gender);  
    		   System.out.println("Gender selected");
    		   test.log(LogStatus.PASS, "Gender selected");
    	   }
    	   catch(Exception e)
    	   {
    		   System.out.println("Gender NOT selected");
    		   System.out.println(e);
    		   test.log(LogStatus.FAIL, "Gender NOT selected !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Gender NOT selected");
    	   }
       }
       
           public static void VerifyElementclicked(WebElement elem) throws IOException, ParserConfigurationException, SAXException
           {
        	   try
        	   {
        		   elem.click();
        		   System.out.println("Element Clicked !");
        		   test.log(LogStatus.PASS, "Web Element Clicked !");
        	   }
        	   catch (Exception e)
        	   {
        		   System.out.println("Element Was NOT Clicked !");
        		   test.log(LogStatus.FAIL, "Element Was NOT Clicked !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
        		   fail("Element Was NOT Clicked !");
        	   }
       }
       
       public static void VerifyElementExist(WebElement elem) throws IOException, ParserConfigurationException, SAXException
       {
    	   try
    	   {
    		   elem.isDisplayed();
    		   System.out.println("Element Exists !");
    		   test.log(LogStatus.PASS, "Element Exists !");
    	   }
    	   catch (Exception e)
    	   {
    		   System.out.println("Element Does NOT exists !");
    		   test.log(LogStatus.FAIL, "Element Does NOT exists !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Element Does NOT exists !");
    	   }
       }
       
       public static void VerifyValueExist(WebElement elem, String ExpectedValue) throws IOException, ParserConfigurationException, SAXException
       {
    	   try
    	   {
    		   String ActualValue = elem.getText();
    		  assertEquals(ActualValue, ExpectedValue);
    		   System.out.println("Value Exists !");
    		   test.log(LogStatus.PASS, "Value Exists !");
    	   }
    	   catch (Exception e)
    	   {
    		   System.out.println("Value Does NOT exists ! " + e.getMessage());
    		   test.log(LogStatus.FAIL, "Value Does NOT exists !, see Screen Shot: " +e.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Value Does NOT exists !");
    	   }
    	   catch (AssertionError ea)
    	   {
    		   System.out.println("Assert Failed ! " + ea.getMessage());
    		   test.log(LogStatus.FAIL, "Assert Failed !, see Screen Shot: " +ea.getMessage() + test.addScreenCapture(TakeSS()));
    		   fail("Assert Failed !");
    	   }
       }
    	   
    	   public static void VerifyImageExist(String ImageName) throws IOException, ParserConfigurationException, SAXException
           {
        	   try
        	   {
        		   screen.find(GetData("ImagePath") + ImageName);
        		   System.out.println("Image Exists !");
        		   test.log(LogStatus.PASS, "Image Exists !");
        	   }
        	   catch (Exception e)
        	   {
        		   System.out.println("Image Does NOT exists !");
        		   test.log(LogStatus.FAIL, "Image Does NOT exists !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
        		   fail("Image Does NOT exists !");
        	   }
           }
       }
       