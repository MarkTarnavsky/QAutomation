package PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import Utilities.Base;

public class SignUpFooter extends Base
{
    @FindBy(how = How.XPATH, using = "//*[@id='js_0']/ul/li[7]/a")
    public WebElement People;
    
    @FindBy(how = How.XPATH, using = "//a[@href ='https://developers.facebook.com/?ref=pf']")
    public WebElement Developers;
    
    @FindBy(how = How.XPATH, using = "//*[@id='js_0']/ul/li[8]/a")
    public WebElement Pages;
    
    @FindBy(how = How.XPATH, using = "//*[@id='js_0']/ul/li[14]/a")
    public WebElement Groups;

}
