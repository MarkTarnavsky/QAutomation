package PageObjects;

import org.openqa.selenium.support.PageFactory;

import Utilities.Base;
public class ManagePages extends Base
{
     public static void init()
     {
    	 su = PageFactory.initElements(driver, PageObjects.SignUp.class);
    	 dp = PageFactory.initElements(driver, PageObjects.Developers.class);
    	 sf = PageFactory.initElements(driver, PageObjects.SignUpFooter.class);
     }
}
