package PageObjects;

import static org.junit.Assert.fail;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import com.relevantcodes.extentreports.LogStatus;

import Utilities.Base;
import Utilities.CommonOps;

public class SignUp extends Base 
{
	@FindBy(how = How.NAME, using = "firstname")
    public WebElement FirstName;

     @FindBy(how = How.NAME, using = "lastname")
     public WebElement LastName;
     
     @FindBy(how = How.NAME, using = "reg_email__")
     public WebElement EmailAdressOrPhoneNumber;
     
     @FindBy(how = How.NAME, using = "reg_email_confirmation__")
     public WebElement ReEnterEmail;
     
     @FindBy(how = How.NAME, using = "reg_passwd__")
     public WebElement Password;
     
     @FindBy(how = How.ID, using = "month")
     public WebElement Month;
     
     @FindBy(how = How.ID, using = "day")
     public WebElement Day;
     
     @FindBy(how = How.ID, using = "year")
     public WebElement Year;
     
     @FindBy(how = How.XPATH, using = "//div/span/span/input[@value='1']")
     public static WebElement Female;
  
     @FindBy(how = How.XPATH, using = "//div/span/span/input[@value='2']")
     public WebElement Male;
     
     @FindBy(how = How.NAME, using = "websubmit")
     public WebElement Submit;
     
     @FindBy(how = How.ID, using = "reg_error_inner")
     public WebElement PassTooShort;

     public void RegisterNewUser() throws IOException, ParserConfigurationException, SAXException
     {
    	 try
    	 {
    	   su.FirstName.sendKeys("Mark");
    	   test.log(LogStatus.PASS, "First Name Inserted");
    	   su.LastName.sendKeys("Tarnavsky");
    	   test.log(LogStatus.PASS, "Last Name Inserted");
    	   su.EmailAdressOrPhoneNumber.sendKeys("Mark.44@gmail.com");
    	   test.log(LogStatus.PASS, "Email Adress Inserted");
    	   su.ReEnterEmail.sendKeys("Mark.44@gmail.com");
    	   test.log(LogStatus.PASS, "Email Adress Re-Inserted ");
    	   su.Password.sendKeys("12345");
    	   test.log(LogStatus.PASS, "Password Inserted");
    	   CommonOps.SelectBirthDayDay(su.Day, "14");
    	   CommonOps.SelectBirthDayMonth(su.Month, "8");
    	   CommonOps.SelectBirthDayYear(su.Year, "1980");
    	   CommonOps.VerifyElementclicked(su.Male);
    	   test.log(LogStatus.PASS, "Gender Inserted");
    	   CommonOps.VerifyElementclicked(su.Submit);
    	   test.log(LogStatus.PASS, "Form Submited");
    	   wait.until(ExpectedConditions.visibilityOf(su.PassTooShort));
    	   CommonOps.VerifyValueExist(su.PassTooShort, "Your password must be at least 6 characters long. Please try another.");
    	 }
    	 catch  (Exception e)
    	 {
  		   System.out.println("Sign Up Failed !");
  		   test.log(LogStatus.FAIL, "Sign Up Failed !, see Screen Shot: " + e.getMessage() + test.addScreenCapture(TakeSS()));
  		   fail("Sign Up Failed !");
    	 }
     }
}
