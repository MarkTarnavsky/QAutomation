package PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import Utilities.Base;

public class Developers extends Base
{

	@FindBy(how = How.XPATH, using = "//*[@id='facebook']/body/div[2]/div[2]/div/div[2]/section[1]/div/a[1]/div/div[2]")
    public WebElement FacebookLogin;
	
	@FindBy(how = How.XPATH, using = "//*[@id='facebook']/body/div[2]/div[2]/div/div[2]/section[1]/div/a[2]/div/div[2]")
    public WebElement SharingOnFacebook;
	
	@FindBy(how = How.XPATH, using = "//*[@id='facebook']/body/div[2]/div[2]/div/div[2]/section[1]/div/a[3]/div/div[2]")
    public WebElement FacebookAnalytics;
	
	@FindBy(how = How.XPATH, using = "//*[@id='facebook']/body/div[2]/div[2]/div/div[2]/section[1]/div/a[4]/div/div[2]")
    public WebElement MobileMonetization;
	
	@FindBy(how = How.CLASS_NAME, using = "_3pte")
    public WebElement MessengerPlatform;
	
	@FindBy(how = How.XPATH, using = "//*[@id='facebook']/body/div[2]/div[2]/div/div[2]/section[1]/div/a[6]/div/div[2]")
    public WebElement InstagramPlatform;
	
}
