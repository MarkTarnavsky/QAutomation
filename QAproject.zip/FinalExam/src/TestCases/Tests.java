package TestCases;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.junit.Test;
import org.xml.sax.SAXException;
import Utilities.Base;
import Utilities.CommonOps;
public class Tests extends Base 
{
     @Test
     public void Test1_FacebookSignIn() throws IOException, ParserConfigurationException, SAXException
     {
    	 su.RegisterNewUser();
     }
     
     @Test
     public void Test2_DevelopersCheck() throws IOException, ParserConfigurationException, SAXException
     {
    	 CommonOps.VerifyElementclicked(sf.Developers);
    	 CommonOps.VerifyElementExist(dp.MessengerPlatform);
    	 CommonOps.VerifyImageExist("DevelopersFaceBookLogin.PNG");
     }
}
